export * from './table-model';
